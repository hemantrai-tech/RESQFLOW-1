# ResQFlow
Agentic emergency-response intelligence: turns fragmented, multilingual reports into evidence-backed incidents and human-approved response actions.

## Run
    node server.js        # Node 18+, no npm install needed
    open http://localhost:3000
Optional: `OPENAI_API_KEY=sk-... AI_MODEL=gpt-4o-mini node server.js` enables LLM extraction (falls back to rules if the call fails).

## Architecture
Browser (index.html) <-> REST API + Server-Sent Events (server.js) <-> data.json
- POST /api/reports: extract (LLM or rules) -> cluster -> triage
- POST /api/simulate/start|reset: scripted flood scenario
- POST /api/incidents/:id/approve|reject|info: human decision, recorded with operator and time
- GET /api/state, GET /api/events (realtime updates)

## Limits
Simulated tasks only; no auth yet (operator is a header); JSON file storage instead of Supabase; semantic similarity is a type tag, not embeddings.
